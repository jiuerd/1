"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tools = require("./lib/tools");
const options_1 = require("./options");
const listener_1 = require("./listener");
const user_1 = require("./user");
const raffle_1 = require("./raffle");
class BiLive {
    constructor() {
        this._lastTime = '';
    }
    async Start() {
        let option = await tools.Options();
        exports._options = option;
        tools.testIP(exports._options.apiIPs);
        for (let uid in exports._options.user) {
            if (!exports._options.user[uid].status)
                continue;
            let user = new user_1.User(uid, exports._options.user[uid]);
            await user.Start();
        }
        this.Options();
        this.Listener();
        exports._user.forEach(user => user.daily());
        this.loop = setInterval(() => this._loop(), 5e+4);
    }
    _loop() {
        let csttime = Date.now() + 2.88e+7, cst = new Date(csttime), cstString = cst.toUTCString().substr(17, 5);
        if (cstString === this._lastTime)
            return;
        this._lastTime = cstString;
        let cstHour = cst.getUTCHours(), cstMin = cst.getUTCMinutes();
        if (cstString === '00:10') {
            exports._user.forEach(user => user.nextDay());
            tools.testIP(exports._options.apiIPs).catch(tools.Error);
        }
        else if (cstString === '13:30')
            exports._user.forEach(user => user.sendGift().catch(error => { tools.Error(user.userData.nickname, error); }));
        if (cstMin === 30 && cstHour % 8 === 0)
            exports._user.forEach(user => user.daily());
    }
    Options() {
        const SOptions = new options_1.Options();
        SOptions.Start();
    }
    Listener() {
        const SListener = new listener_1.Listener();
        SListener
            .on('raffle', this._Raffle.bind(this))
            .Start();
    }
    _Raffle(raffleMSG) {
        exports._user.forEach(user => {
            if (!user.userData.raffle)
                return;
            let raffleOptions = {
                raffleId: raffleMSG.id,
                roomID: raffleMSG.roomID,
                User: user
            };
            switch (raffleMSG.cmd) {
                case 'smallTV':
                    new raffle_1.Raffle(raffleOptions).SmallTV().catch(error => { tools.Error(user.userData.nickname, raffleMSG.cmd, raffleMSG.id, error); });
                    break;
                case 'raffle':
                    new raffle_1.Raffle(raffleOptions).Raffle().catch(error => { tools.Error(user.userData.nickname, raffleMSG.cmd, raffleMSG.id, error); });
                    break;
                case 'lighten':
                    new raffle_1.Raffle(raffleOptions).Lighten().catch(error => { tools.Error(user.userData.nickname, raffleMSG.cmd, raffleMSG.id, error); });
                    break;
                case 'appLighten':
                    raffleOptions.type = raffleMSG.type;
                    new raffle_1.Raffle(raffleOptions).AppLighten().catch(error => { tools.Error(user.userData.nickname, raffleMSG.cmd, raffleMSG.id, error); });
                    break;
                default:
                    break;
            }
        });
    }
}
exports.BiLive = BiLive;
exports.liveOrigin = 'http://live.bilibili.com', exports.apiLiveOrigin = 'http://api.live.bilibili.com', exports.smallTVPathname = '/gift/v2/smalltv', exports.rafflePathname = '/activity/v1/Raffle', exports.lightenPathname = '/activity/v1/NeedYou', exports._user = new Map();
