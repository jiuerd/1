"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tools = require("./lib/tools");
const app_client_1 = require("./lib/app_client");
const index_1 = require("./index");
class User {
    constructor(uid, userData) {
        this._sign = false;
        this._treasureBox = false;
        this._eventRoom = false;
        this.uid = uid;
        this.userData = userData;
    }
    get baseQuery() {
        return `access_key=${this.userData.accessToken}&${app_client_1.AppClient.baseQuery}`;
    }
    async Start() {
        index_1._user.set(this.uid, this);
        this.jar = tools.setCookie(this.userData.cookie, [index_1.apiLiveOrigin]);
        let test = await this._heart().catch(error => { return error; });
        if (test === 'stop')
            return;
        this._heartloop = setInterval(() => this._heart(), 3e+5);
    }
    Stop() {
        index_1._user.delete(this.uid);
        if (this._heartloop != null)
            clearInterval(this._heartloop);
    }
    nextDay() {
        this._sign = false;
        this._treasureBox = false;
        this._eventRoom = false;
    }
    async _heart() {
        let heartTest = await this._onlineHeart().catch(error => { return error; });
        if (typeof heartTest === 'string')
            await this._cookieError().catch(error => { return error; });
    }
    async _onlineHeart() {
        let online = {
            method: 'POST',
            uri: `${index_1.apiLiveOrigin}/User/userOnlineHeart`,
            jar: this.jar,
            json: true,
            headers: {
                'Referer': `${index_1.liveOrigin}/${index_1._options.config.defaultRoomID}`
            }
        }, heartPC = await tools.XHR(online);
        if (heartPC.response.statusCode === 200 && heartPC.body.code === 3)
            throw 'cookieError';
        let heartbeat = {
            method: 'POST',
            uri: `${index_1.apiLiveOrigin}/mobile/userOnlineHeart?${app_client_1.AppClient.ParamsSign(this.baseQuery)}`,
            body: `room_id=${index_1._options.config.defaultRoomID}&scale=xxhdpi`,
            json: true
        }, heart = await tools.XHR(heartbeat, 'Android');
        if (heart.response.statusCode === 200 && heart.body.code === 3)
            throw 'tokenError';
    }
    async _cookieError() {
        tools.Log(this.userData.nickname, 'Cookie已失效');
        let cookie = await app_client_1.AppClient.GetCookie(this.userData.accessToken);
        if (cookie != null) {
            this.jar = cookie;
            this.userData.cookie = cookie.getCookieString(index_1.apiLiveOrigin);
            this.userData.biliUID = parseInt(tools.getCookie(cookie, 'DedeUserID'));
            tools.Options(index_1._options);
            tools.Log(this.userData.nickname, 'Cookie已更新');
        }
        else
            return this._tokenError();
    }
    async _tokenError() {
        tools.Log(this.userData.nickname, 'Token已失效');
        let token = await app_client_1.AppClient.GetToken({
            userName: this.userData.userName,
            passWord: this.userData.passWord
        });
        if (typeof token === 'string') {
            this.userData.accessToken = token;
            tools.Options(index_1._options);
            tools.Log(this.userData.nickname, 'Token已更新');
            await this._cookieError();
        }
        else if (token != null && token.response.statusCode === 200) {
            this.Stop();
            this.userData.status = false;
            tools.Options(index_1._options);
            tools.Log(this.userData.nickname, 'Token更新失败', token.body);
            throw 'stop';
        }
        else
            tools.Log(this.userData.nickname, 'Token更新失败');
    }
    async daily() {
        await this.sign().catch(error => { tools.Error(this.userData.nickname, '每日签到', error); });
        this.treasureBox().catch(error => { tools.Error(this.userData.nickname, '每日宝箱', error); });
        this.eventRoom().catch(error => { tools.Error(this.userData.nickname, '每日任务', error); });
        this.sendGift().catch(error => { tools.Error(this.userData.nickname, '自动送礼', error); });
        this.signGroup().catch(error => { tools.Error(this.userData.nickname, '应援团签到', error); });
    }
    async sign() {
        if (this._sign || !this.userData.doSign)
            return;
        let ok = 0;
        let sign = {
            uri: `${index_1.apiLiveOrigin}/AppUser/getSignInfo?${app_client_1.AppClient.ParamsSign(this.baseQuery)}`,
            json: true
        }, signInfo = await tools.XHR(sign, 'Android');
        if (signInfo.response.statusCode === 200 && signInfo.body.code === 0) {
            ok += 1;
            tools.Log(this.userData.nickname, '每日签到', '已签到');
        }
        let getBag = {
            uri: `${index_1.apiLiveOrigin}/AppBag/getSendGift?${app_client_1.AppClient.ParamsSign(this.baseQuery)}`,
            json: true
        }, getBagGift = await tools.XHR(getBag, 'Android');
        if (getBagGift.response.statusCode === 200 && getBagGift.body.code === 0) {
            ok += 1;
            tools.Log(this.userData.nickname, '每日签到', '已获取每日包裹');
        }
        if (ok === 2)
            this._sign = true;
    }
    async treasureBox() {
        if (this._treasureBox || !this.userData.treasureBox)
            return;
        let current = {
            uri: `${index_1.apiLiveOrigin}/mobile/freeSilverCurrentTask?${app_client_1.AppClient.ParamsSign(this.baseQuery)}`,
            json: true
        }, currentTask = await tools.XHR(current, 'Android');
        if (currentTask.response.statusCode === 200) {
            if (currentTask.body.code === 0) {
                await tools.Sleep(currentTask.body.data.minute * 6e4);
                let award = {
                    uri: `${index_1.apiLiveOrigin}/mobile/freeSilverAward?${app_client_1.AppClient.ParamsSign(this.baseQuery)}`,
                    json: true
                };
                await tools.XHR(award, 'Android');
                this.treasureBox();
            }
            else if (currentTask.body.code === -10017) {
                this._treasureBox = true;
                tools.Log(this.userData.nickname, '每日宝箱', '已领取所有宝箱');
            }
        }
    }
    async eventRoom() {
        if (this._eventRoom || !this.userData.eventRoom)
            return;
        let roomID = index_1._options.config.eventRooms[0], biliUID = this.userData.biliUID, md5 = tools.Hash('md5', `${biliUID}${roomID}bilibili`), sha1 = tools.Hash('sha1', `${md5}bilibili`), baseQuery = `access_key=${this.userData.accessToken}&${app_client_1.AppClient.baseQuery}`, share = {
            uri: `${index_1.apiLiveOrigin}/activity/v1/Common/shareCallback?${app_client_1.AppClient.ParamsSign(`roomid=${roomID}&sharing_plat=weibo&share_sign=${sha1}&${baseQuery}`)}`,
            json: true
        };
        let shareCallback = await tools.XHR(share, 'Android');
        if (shareCallback.response.statusCode === 200 && shareCallback.body.code === 0)
            tools.Log(this.userData.nickname, '每日任务', `分享房间 ${roomID} 成功`);
        else
            tools.Log(this.userData.nickname, '每日任务', shareCallback.body.msg);
        let ok = 0, task = ['single_watch_task', 'double_watch_task', 'share_task'];
        task.forEach(value => {
            let task = {
                method: 'POST',
                uri: `${index_1.apiLiveOrigin}/activity/v1/task/receive_award`,
                body: `task_id=${value}`,
                jar: this.jar,
                json: true,
                headers: {
                    'Referer': `${index_1.liveOrigin}/${roomID}`
                }
            };
            tools.XHR(task, 'WebView')
                .then(taskres => {
                if (taskres.response.statusCode === 200)
                    ok += 1;
                if (ok = 3)
                    this._eventRoom = true;
            })
                .catch(error => { tools.Error(this.userData.nickname, '每日任务', error); });
        });
    }
    async sendGift() {
        if (!this.userData.sendGift)
            return;
        let roomID = this.userData.sendGiftRoom, room = {
            uri: `${index_1.apiLiveOrigin}/AppRoom/index?${app_client_1.AppClient.ParamsSign(`room_id=${roomID}&${app_client_1.AppClient.baseQuery}`)}`,
            json: true
        }, roomInfo = await tools.XHR(room, 'Android');
        if (roomInfo.response.statusCode === 200 && roomInfo.body.code === 0) {
            let mid = roomInfo.body.data.mid, room_id = roomInfo.body.data.room_id, bag = {
                uri: `${index_1.apiLiveOrigin}/gift/v2/gift/m_bag_list?${app_client_1.AppClient.ParamsSign(this.baseQuery)}`,
                json: true
            }, bagInfo = await tools.XHR(bag, 'Android');
            if (bagInfo.response.statusCode === 200 && bagInfo.body.code === 0) {
                if (bagInfo.body.data.length > 0) {
                    for (let giftData of bagInfo.body.data) {
                        if (giftData.expireat > 0 && giftData.expireat < 8.64e+4) {
                            let send = {
                                method: 'POST',
                                uri: `${index_1.apiLiveOrigin}/gift/v2/live/bag_send`,
                                body: app_client_1.AppClient.ParamsSign(`bag_id=${giftData.id}&biz_code=live&biz_id=${room_id}&gift_id=${giftData.gift_id}&gift_num=${giftData.gift_num}&ruid=${mid}&uid=${giftData.uid}&rnd=${app_client_1.AppClient.RND}&${this.baseQuery}`),
                                json: true
                            }, sendBag = await tools.XHR(send, 'Android');
                            if (sendBag.response.statusCode === 200 && sendBag.body.code === 0) {
                                let sendBagData = sendBag.body.data;
                                tools.Log(this.userData.nickname, '自动送礼', `向房间 ${roomID} 赠送 ${sendBagData.gift_num} 个${sendBagData.gift_name}`);
                            }
                            else
                                tools.Log(this.userData.nickname, '自动送礼', `向房间 ${roomID} 赠送 ${giftData.gift_num} 个${giftData.gift_name} 失败`, sendBag.body);
                            await tools.Sleep(3e+3);
                        }
                    }
                }
            }
            else
                tools.Log(this.userData.nickname, '自动送礼', '获取包裹信息失败', bagInfo.body);
        }
        else
            tools.Log(this.userData.nickname, '自动送礼', '获取房间信息失败', roomInfo.body);
    }
    async signGroup() {
        if (!this.userData.signGroup)
            return;
        let group = {
            uri: `${index_1.apiLiveOrigin}/link_group/v1/member/my_groups?${app_client_1.AppClient.ParamsSign(this.baseQuery)}`,
            json: true
        }, linkGroup = await tools.XHR(group, 'Android');
        if (linkGroup.response.statusCode === 200 && linkGroup.body.code === 0) {
            if (linkGroup.body.data.list.length > 0) {
                for (let groupInfo of linkGroup.body.data.list) {
                    let sign = {
                        uri: `${index_1.apiLiveOrigin}/link_setting/v1/link_setting/sign_in?${app_client_1.AppClient.ParamsSign(`group_id=${groupInfo.group_id}&owner_id=${groupInfo.owner_uid}&${this.baseQuery}`)}`,
                        json: true
                    }, signGroup = await tools.XHR(sign, 'Android');
                    if (signGroup.response.statusCode === 200 && signGroup.body.data.add_num > 0)
                        tools.Log(this.userData.nickname, '应援团签到', `在${groupInfo.group_name}签到获得 ${signGroup.body.data.add_num} 点亲密度`);
                    else
                        tools.Log(this.userData.nickname, '应援团签到', `已在${groupInfo.group_name}签到过`);
                    await tools.Sleep(3e+3);
                }
            }
        }
        else
            tools.Log(this.userData.nickname, '应援团签到', '获取应援团列表失败', linkGroup.body);
    }
}
exports.User = User;
