"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tools = require("./lib/tools");
const app_client_1 = require("./lib/app_client");
const index_1 = require("./index");
class Raffle {
    constructor(raffleOptions) {
        if (raffleOptions.type != null)
            this._type = raffleOptions.type;
        this._raffleId = raffleOptions.raffleId;
        this._roomID = raffleOptions.roomID;
        this._User = raffleOptions.User;
    }
    SmallTV() {
        this._url = index_1.apiLiveOrigin + index_1.smallTVPathname;
        return this._Raffle();
    }
    Raffle() {
        this._url = index_1.apiLiveOrigin + index_1.rafflePathname;
        return this._Raffle();
    }
    async _Raffle() {
        let join = {
            uri: `${this._url}/join?roomid=${this._roomID}&raffleId=${this._raffleId}`,
            jar: this._User.jar,
            json: true,
            headers: {
                'Referer': `${index_1.liveOrigin}/${this._roomID}`
            }
        }, raffleJoin = await tools.XHR(join);
        if (raffleJoin.response.statusCode === 200 && raffleJoin.body.code === 0) {
            let time = raffleJoin.body.data.time * 1e+3 + 3e+4;
            await tools.Sleep(time);
            this._RaffleReward().catch(error => { tools.Error(this._User.userData.nickname, '获取抽奖结果', this._raffleId, error); });
        }
    }
    async _RaffleReward() {
        let reward = {
            uri: `${this._url}/notice?roomid=${this._roomID}&raffleId=${this._raffleId}`,
            jar: this._User.jar,
            json: true,
            headers: {
                'Referer': `${index_1.liveOrigin}/${this._roomID}`
            }
        }, raffleReward = await tools.XHR(reward);
        if (raffleReward.response.statusCode !== 200)
            return;
        if (raffleReward.body.code === -400 || raffleReward.body.data.status === 3) {
            await tools.Sleep(3e+4);
            this._RaffleReward().catch(error => { tools.Error(this._User.userData.nickname, '获取抽奖结果', this._raffleId, error); });
        }
        else {
            let gift = raffleReward.body.data;
            if (gift.gift_num === 0)
                tools.Log(this._User.userData.nickname, `抽奖 ${this._raffleId}`, raffleReward.body.msg);
            else
                tools.Log(this._User.userData.nickname, `抽奖 ${this._raffleId}`, `获得 ${gift.gift_num} 个${gift.gift_name}`);
        }
    }
    async Lighten() {
        this._url = index_1.apiLiveOrigin + index_1.lightenPathname;
        let getCoin = {
            method: 'POST',
            uri: `${this._url}/getCoin`,
            body: `roomid=${this._roomID}&lightenId=${this._raffleId}}`,
            jar: this._User.jar,
            json: true,
            headers: {
                'Referer': `${index_1.liveOrigin}/${this._roomID}`
            }
        }, lightenReward = await tools.XHR(getCoin);
        if (lightenReward.response.statusCode === 200 && lightenReward.body.code === 0)
            tools.Log(this._User.userData.nickname, `抽奖 ${this._raffleId}`, lightenReward.body.msg);
    }
    async AppLighten() {
        let baseQuery = `access_key=${this._User.userData.accessToken}&${app_client_1.AppClient.baseQuery}`, reward = {
            uri: `${index_1.apiLiveOrigin}/YunYing/roomEvent?${app_client_1.AppClient.ParamsSign(`event_type=${this._type}-${this._raffleId}&room_id=${this._roomID}&${baseQuery}`)}`,
            json: true
        }, appLightenReward = await tools.XHR(reward, 'Android');
        if (appLightenReward.response.statusCode === 200 && appLightenReward.body.code === 0)
            tools.Log(this._User.userData.nickname, `抽奖 ${this._raffleId}`, `获得${appLightenReward.body.data.gift_desc}`);
    }
}
exports.Raffle = Raffle;
