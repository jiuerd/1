"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tools = require("./lib/tools");
const events_1 = require("events");
const app_client_1 = require("./lib/app_client");
const comment_client_1 = require("./lib/comment_client");
const index_1 = require("./index");
class Listener extends events_1.EventEmitter {
    constructor() {
        super();
        this._smallTVID = 0;
        this._raffleID = 0;
        this._lightenID = 0;
        this._appLightenID = 0;
    }
    Start() {
        let config = index_1._options.config, roomID = config.defaultRoomID, userID = config.defaultUserID;
        this._CommentClient = new comment_client_1.CommentClient({ roomID, userID });
        this._CommentClient
            .on('serverError', error => { tools.Error('弹幕服务器监听', error); })
            .on('SYS_MSG', this._SYSMSGHandler.bind(this))
            .on('SYS_GIFT', this._SYSGiftHandler.bind(this))
            .Connect();
    }
    _SYSMSGHandler(dataJson) {
        if (dataJson.real_roomid == null || dataJson.tv_id == null)
            return;
        let url = index_1.apiLiveOrigin + index_1.smallTVPathname, roomID = dataJson.real_roomid;
        this._RaffleCheck(url, roomID, 'smallTV').catch(error => { tools.Error('系统消息', roomID, error); });
    }
    _SYSGiftHandler(dataJson) {
        if (dataJson.real_roomid == null || dataJson.giftId == null)
            return;
        let url = index_1.apiLiveOrigin + index_1.rafflePathname, roomID = dataJson.real_roomid;
        this._RaffleCheck(url, roomID, 'raffle').catch(error => { tools.Error('系统礼物消息', roomID, error); });
    }
    async _RaffleCheck(url, roomID, raffle) {
        let check = {
            uri: `${url}/check?roomid=${roomID}`,
            json: true,
            headers: {
                'Referer': `${index_1.liveOrigin}/${roomID}`
            }
        }, raffleCheck = await tools.XHR(check);
        if (raffleCheck.response.statusCode === 200 && raffleCheck.body.code === 0 && raffleCheck.body.data.length > 0) {
            raffleCheck.body.data.forEach(data => {
                let message = {
                    cmd: raffle,
                    roomID,
                    id: +data.raffleId
                };
                this._RaffleHandler(message);
                if (raffle === 'raffle') {
                    let message = {
                        cmd: 'appLighten',
                        roomID,
                        id: +data.raffleId,
                        type: 'openfire'
                    };
                    this._RaffleHandler(message);
                }
            });
        }
    }
    async _AppLightenCheck(roomID) {
        let room = {
            uri: `${index_1.apiLiveOrigin}/AppRoom/index?${app_client_1.AppClient.ParamsSign(`room_id=${roomID}&${app_client_1.AppClient.baseQuery}`)}`,
            json: true
        }, roomInfo = await tools.XHR(room, 'Android');
        if (roomInfo.response.statusCode === 200 && roomInfo.body.code === 0 && roomInfo.body.data.event_corner.length > 0) {
            roomInfo.body.data.event_corner.forEach(event => {
                let type = event.event_type.split('-');
                if (type.length !== 2)
                    return;
                let message = {
                    cmd: 'appLighten',
                    roomID,
                    id: +type[1],
                    type: type[0]
                };
                this._RaffleHandler(message);
            });
        }
    }
    _RaffleHandler(raffleMSG) {
        let roomID = raffleMSG.roomID, id = raffleMSG.id, msg = '';
        switch (raffleMSG.cmd) {
            case 'smallTV':
                if (this._smallTVID >= id)
                    return;
                this._smallTVID = id;
                msg = '小电视';
                break;
            case 'raffle':
                if (this._raffleID >= id)
                    return;
                this._raffleID = id;
                break;
            case 'lighten':
                if (this._lightenID >= id)
                    return;
                this._lightenID = id;
                break;
            case 'appLighten':
                if (this._appLightenID >= id)
                    return;
                this._appLightenID = id;
                msg = '客户端';
                break;
            default:
                return;
        }
        this.emit('raffle', raffleMSG);
        tools.Log(`房间 ${roomID} 开启了第 ${id} 轮${msg}抽奖`);
    }
}
exports.Listener = Listener;
