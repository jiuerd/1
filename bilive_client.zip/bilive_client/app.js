"use strict";
const BiLive = require(__dirname + '/bilive/index').BiLive;
const bilive = new BiLive();
bilive.Start();
